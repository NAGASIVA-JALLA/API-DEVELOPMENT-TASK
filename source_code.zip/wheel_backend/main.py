from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy import Column, Integer, String, JSON, select
from contextlib import asynccontextmanager
from datetime import datetime
import asyncio

# ✅ Database Config
DATABASE_URL = "postgresql+asyncpg://postgres:siva@localhost/wheel_db1"

engine = create_async_engine(DATABASE_URL, echo=True)
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
Base = declarative_base()

# ✅ Dependency to get DB session
async def get_db():
    async with AsyncSessionLocal() as session:
        yield session

# ✅ Models
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    phone_number = Column(String, unique=True, index=True)
    password = Column(String)
    name = Column(String)
    token = Column(String)

class WheelSpecification(Base):
    __tablename__ = "wheel_specifications"
    id = Column(Integer, primary_key=True, index=True)
    form_number = Column(String)
    submitted_by = Column(String)
    submitted_date = Column(String)
    fields = Column(JSON)
    status = Column(String)

# ✅ Schemas
class LoginRequest(BaseModel):
    phone: str
    password: str

class SubmitFormRequest(BaseModel):
    form_number: str
    submitted_by: str
    submitted_date: str
    fields: dict

# ✅ Dummy user creator
async def create_dummy_user():
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(User).where(User.phone_number == "7760873976")
        )
        user = result.scalars().first()
        if not user:
            dummy_user = User(
                phone_number="7760873976",
                password="to_share@123",
                name="Demo User",
                token="dummy_token_123"
            )
            session.add(dummy_user)
            await session.commit()
            print("✅ Dummy user created.")
        else:
            print("✅ Dummy user already exists.")

# ✅ Lifespan: replaces deprecated @app.on_event
@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    await create_dummy_user()
    yield  # Let FastAPI start

# ✅ App instance
app = FastAPI(lifespan=lifespan)

# ✅ Login Endpoint
@app.post("/api/users/login/")
async def login(data: LoginRequest, db: AsyncSession = Depends(get_db)):
    print(f"🔐 Login attempt with phone: {data.phone}, password: {data.password}")
    result = await db.execute(
        select(User).where(
            User.phone_number == data.phone,
            User.password == data.password
        )
    )
    user = result.scalars().first()
    if user:
        return {
            "success": True,
            "message": "Login successful",
            "data": {
                "user_id": user.id,
                "name": user.name,
                "token": user.token
            }
        }
    raise HTTPException(status_code=401, detail="Invalid credentials")

# ✅ Form Submit Endpoint
@app.post("/api/users/wheel_specs")
async def submit_form(data: SubmitFormRequest, db: AsyncSession = Depends(get_db)):
    print("📦 Incoming data:", data.dict())

    try:
        entry = WheelSpecification(
            form_number=data.form_number,
            submitted_by=data.submitted_by,
            submitted_date=data.submitted_date,
            fields=data.fields,
            status="submitted"
        )
        db.add(entry)
        await db.commit()
        print("Form saved to database.")
        return {
            "success": True,
            "message": "Form submitted successfully"
        }
    except Exception as e:
        await db.rollback()
        print(" Error saving form:", e)
        raise HTTPException(status_code=500, detail="Failed to save form data")


# ✅ Form Get Endpoint
@app.get("/get-form")
async def get_form(
    form_number: str,
    submitted_by: str,
    submitted_date: str,
    db: AsyncSession = Depends(get_db)
):
    allowed_fields = ["treaddiameternew", "lastshopissuesize", "condemningdia", "wheelgauage"]
    result = await db.execute(
        select(WheelSpecification).where(
            WheelSpecification.form_number == form_number,
            WheelSpecification.submitted_by == submitted_by,
            WheelSpecification.submitted_date == submitted_date
        )
    )
    records = result.scalars().all()
    data = []
    for record in records:
        filtered_fields = {k: v for k, v in record.fields.items() if k in allowed_fields}
        data.append({
            "form_number": record.form_number,
            "submitted_by": record.submitted_by,
            "submitted_date": record.submitted_date,
            "fields": filtered_fields
        })
    return {"data": data}

# ✅ Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
