class ApiConstant {
  // static const String baseUrl = 'http://localhost:8000';
  //  static const String baseUrl = 'https://tobapi.suvidhaen.com/api';   // prod url
  static const String baseUrl = 'http://192.168.0.108:8000'; // uat url

}


//https://tobapi.suvidhaen.com/api/user/login/
//https://tobapi.suvidhaen.com/api/users/login/
