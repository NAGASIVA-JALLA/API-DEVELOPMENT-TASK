import 'package:flutter/material.dart';
import '../services/api_services/api_service.dart'; // ✅ Make sure this import is correct

class IcfWheelProvider extends ChangeNotifier {
  bool submitted = false;
  bool isEditing = false;
  bool showSummaryCard = false;
  bool showFilterCard = false; // for filter summary card

  final searchController = TextEditingController();
  final treadDiameterController = TextEditingController(text: "915 (900-1000)");
  final lastShopIssueController = TextEditingController(text: "837 (800-900)");
  final condemningDiaController = TextEditingController(text: "825 (800-900)");
  final wheelGaugeController = TextEditingController(text: "1600 (+2,-1)");

  final List<Map<String, Widget>> allFields = [];
  List<Map<String, Widget>> visibleFields = [];

  String filterFormNumber = '';
  String filterCreatedAt = '';
  String filterCreatedBy = '';

  void initializeFields(List<Map<String, Widget>> fields) {
    allFields.clear();
    allFields.addAll(fields);
    visibleFields = List.from(allFields);
    notifyListeners();
  }

  void filterFields(String query) {
    visibleFields = query.isEmpty
        ? List.from(allFields)
        : allFields
            .where((field) => field.keys.first.toLowerCase().contains(query.toLowerCase()))
            .toList();
    notifyListeners();
  }

  void applyFilter({String formNumber = '', String createdAt = '', String createdBy = ''}) {
    filterFormNumber = formNumber;
    filterCreatedAt = createdAt;
    filterCreatedBy = createdBy;
    showSummaryCard = formNumber.isNotEmpty || createdAt.isNotEmpty || createdBy.isNotEmpty;
    notifyListeners();
  }

  Future<void> handleSubmit(BuildContext context) async {
    try {
      submitted = true;
      isEditing = false;
      notifyListeners();

      // ✅ Required top-level fields
      String formNumber = "ICF-${DateTime.now().millisecondsSinceEpoch}";
      String submittedBy = "Jalla"; // You can replace this with actual user from login
      String submittedDate = DateTime.now().toIso8601String().split("T").first; // YYYY-MM-DD

      // ✅ Collect actual wheel fields into 'fields' key
      Map<String, dynamic> fields = {
        "tread_diameter": treadDiameterController.text,
        "last_shop_issue": lastShopIssueController.text,
        "condemning_diameter": condemningDiaController.text,
        "wheel_gauge": wheelGaugeController.text,
      };

      // ✅ Final payload for FastAPI
      Map<String, dynamic> wheelSpecData = {
        "form_number": formNumber,
        "submitted_by": submittedBy,
        "submitted_date": submittedDate,
        "fields": fields,
      };

      final response = await ApiService.post(
        "/api/users/wheel_specs",
        wheelSpecData,
      );

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Form submitted successfully")),
      );
      debugPrint("✅ Response from backend: $response");

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(" Submission failed: $e")),
      );
      debugPrint("Error during submission: $e");
    }
  }

  void handleEdit() {
    isEditing = true;
    notifyListeners();
  }
}
